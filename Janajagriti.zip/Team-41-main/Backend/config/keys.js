module.exports = {
    mongoURI: 'mongodb+srv://gpandaj:ace135@jagriti.ubetopf.mongodb.net/?retryWrites=true&w=majority',
    secretOrKey : 'secret'
};

